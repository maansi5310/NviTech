# NviTech

AI debugging and code-repair agent for the Nebius x NVIDIA hackathon.
Stack: Python, pytest, Streamlit, VS Code, Nebius Token Factory, NVIDIA Nemotron.

## Workflow

`Analyze → Plan → Generate → Test → Iterate → Report` (see `nvitech/workflow.py`)

1. Baseline: pytest runs on the original code to capture real failure output.
2. Analyze + Plan: Nemotron identifies the root cause and a minimal repair plan.
3. Generate: Nemotron returns the full corrected module; a unified diff is computed locally.
4. Test: the patched module is run against your tests in a restricted sandbox.
5. Iterate: on failure, the failed code and pytest output are fed back (default max 3 attempts).
6. Report: patch, reasoning, before/after test evidence, and an honest status.

### Honest statuses

| Status | Meaning |
|---|---|
| VERIFIED | patch passes the supplied tests |
| UNVERIFIED | patch generated but no tests supplied, so not proven |
| FAILED | no attempt passed; the patch is never offered as a fix |
| NOTHING TO FIX | tests already pass on the original code |
| BLOCKED | the safety scan refused the code |

## Setup (VS Code)

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # then put your Nebius key in .env
```

Open the folder in VS Code and choose the `.venv` interpreter.

## Run

```bash
streamlit run app.py             # or use the "NviTech: Streamlit app" launch config
```

Click **Load buggy example**, then **Repair**.

## Test

```bash
pytest
```

The tests use a scripted fake LLM, so they run offline and need no API key.

## Configuration

Set in `.env` (or the Streamlit sidebar): `NEBIUS_API_KEY`, `NEBIUS_BASE_URL`, `NEBIUS_MODEL`,
`NEMOTRON_REASONING`. **Check your Nebius console for the exact Nemotron model slug and base
URL available to your account**; the defaults are best guesses and may need changing.

## Layout

```
app.py                  Streamlit UI
nvitech/llm.py          Nebius Token Factory client (OpenAI-compatible)
nvitech/prompts.py      Stage prompts
nvitech/workflow.py     Repair loop + patch parsing + diff
nvitech/sandbox.py      Restricted pytest runner
nvitech/models.py       Dataclasses
examples/               Buggy sample + tests
tests/                  pytest suite (offline)
```

## Safety note

The sandbox uses a static scan, temp dir, stripped environment (API keys are not passed),
timeout, and POSIX resource limits. It is **not** a hard security boundary. For untrusted code
in a real deployment, run NviTech inside a Docker container or VM with networking disabled.
Resource limits are not applied on Windows.

## Roadmap

Multi-file projects, repo-level analysis, regression tests, strategy comparison, failure-pattern tracking.
