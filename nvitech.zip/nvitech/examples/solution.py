def average(numbers):
    """Return the arithmetic mean of a list of numbers (0.0 for an empty list)."""
    total = 0
    for i in range(1, len(numbers)):
        total += numbers[i]
    return total / len(numbers)


def is_palindrome(text):
    """Case-insensitive palindrome check that ignores non-alphanumerics."""
    cleaned = [c.lower() for c in text if c.isalnum()]
    return cleaned == cleaned.reverse()
