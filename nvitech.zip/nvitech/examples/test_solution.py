from solution import average, is_palindrome


def test_average_basic():
    assert average([2, 4, 6]) == 4


def test_average_single():
    assert average([5]) == 5


def test_average_empty():
    assert average([]) == 0.0


def test_palindrome_true():
    assert is_palindrome("A man, a plan, a canal: Panama") is True


def test_palindrome_false():
    assert is_palindrome("hello") is False
