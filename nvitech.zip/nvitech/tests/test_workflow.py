from nvitech.workflow import RepairWorkflow, make_diff, parse_generation
from tests.conftest import FakeLLM, gen_reply

BAD = "def add(a, b):\n    return a - b\n"
GOOD = "def add(a, b):\n    return a + b\n"
STILL_BAD = "def add(a, b):\n    return a * b\n"
TESTS = "from solution import add\n\ndef test_add():\n    assert add(1, 2) == 3\n"


def test_parse_generation_tags():
    expl, code = parse_generation(gen_reply(GOOD, "swap operator"))
    assert expl == "swap operator" and code == GOOD


def test_parse_generation_strips_inner_fence():
    expl, code = parse_generation(f"<fixed_code>\n```python\n{GOOD}```\n</fixed_code>")
    assert code == GOOD


def test_parse_generation_fallback_fence():
    _, code = parse_generation(f"Here:\n```python\n{GOOD}```")
    assert code == GOOD


def test_parse_generation_rejects_garbage():
    try:
        parse_generation("sorry, I cannot help")
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_make_diff_shows_change():
    d = make_diff(BAD, GOOD)
    assert "-    return a - b" in d and "+    return a + b" in d


def test_verified_on_first_attempt():
    llm = FakeLLM(["root cause", "plan", gen_reply(GOOD)])
    report = RepairWorkflow(llm).run(BAD, TESTS)
    assert report.status == "verified"
    assert len(report.attempts) == 1
    assert report.best_code == GOOD


def test_iterates_after_failure_and_feeds_back_output():
    llm = FakeLLM(["rc", "plan", gen_reply(STILL_BAD), gen_reply(GOOD)])
    report = RepairWorkflow(llm, max_attempts=3).run(BAD, TESTS)
    assert report.status == "verified"
    assert len(report.attempts) == 2
    # the second generate prompt must include the failed attempt and its test output
    last_prompt = llm.calls[-1][1]
    assert "Failed attempt 1" in last_prompt and "return a * b" in last_prompt


def test_fails_after_max_attempts_and_hides_best_code():
    llm = FakeLLM(["rc", "plan"] + [gen_reply(STILL_BAD)] * 2)
    report = RepairWorkflow(llm, max_attempts=2).run(BAD, TESTS)
    assert report.status == "failed"
    assert report.best_code is None  # never offer an unverified-failing fix as good


def test_unparseable_reply_counts_as_attempt():
    llm = FakeLLM(["rc", "plan", "no code here", gen_reply(GOOD)])
    report = RepairWorkflow(llm, max_attempts=3).run(BAD, TESTS)
    assert report.status == "verified"
    assert report.attempts[0].parse_error


def test_no_tests_is_unverified_never_verified():
    llm = FakeLLM(["rc", "plan", gen_reply(GOOD)])
    report = RepairWorkflow(llm).run(BAD, "", traceback="TypeError ...")
    assert report.status == "unverified"
    assert report.attempts[0].test_result is None


def test_already_passing_makes_no_llm_calls():
    llm = FakeLLM([])
    report = RepairWorkflow(llm).run(GOOD, TESTS)
    assert report.status == "already_passing" and llm.calls == []


def test_blocked_original_code():
    evil = "import subprocess\n\ndef add(a, b):\n    return a + b\n"
    llm = FakeLLM([])
    report = RepairWorkflow(llm).run(evil, TESTS)
    assert report.status == "blocked" and llm.calls == []


def test_events_emitted_in_order():
    events = []
    llm = FakeLLM(["rc", "plan", gen_reply(GOOD)])
    RepairWorkflow(llm, on_event=lambda s, m: events.append(s)).run(BAD, TESTS)
    assert events[:3] == ["test", "analyze", "plan"]
    assert "generate" in events and events[-1] == "report"
