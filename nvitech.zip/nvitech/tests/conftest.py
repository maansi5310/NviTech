"""Shared test helpers."""

import pytest


class FakeLLM:
    """Returns scripted replies in order; records prompts."""

    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = []

    def complete(self, system, user):
        self.calls.append((system, user))
        return self.replies.pop(0)


def gen_reply(code, explanation="fixed it"):
    return f"<explanation>\n{explanation}\n</explanation>\n<fixed_code>\n{code}\n</fixed_code>"


@pytest.fixture
def fake_llm_cls():
    return FakeLLM
