import sys
import types

import pytest

from nvitech.llm import LLMError, NebiusNemotronClient


@pytest.fixture(autouse=True)
def stub_openai(monkeypatch):
    """Provide a fake `openai` module so these tests run offline without the SDK."""
    fake = types.ModuleType("openai")

    class OpenAI:
        def __init__(self, base_url=None, api_key=None):
            self.base_url, self.api_key = base_url, api_key

    fake.OpenAI = OpenAI
    monkeypatch.setitem(sys.modules, "openai", fake)


def test_missing_key_raises(monkeypatch):
    monkeypatch.delenv("NEBIUS_API_KEY", raising=False)
    with pytest.raises(LLMError):
        NebiusNemotronClient(api_key="")


def test_env_overrides(monkeypatch):
    monkeypatch.setenv("NEBIUS_API_KEY", "k")
    monkeypatch.setenv("NEBIUS_MODEL", "my/model")
    monkeypatch.setenv("NEBIUS_BASE_URL", "https://example.test/v1/")
    c = NebiusNemotronClient()
    assert c.model == "my/model" and c.base_url == "https://example.test/v1/"


def _client_returning(content, captured):
    c = NebiusNemotronClient(api_key="k")

    class Msg:
        pass

    Msg.content = content
    resp = types.SimpleNamespace(choices=[types.SimpleNamespace(message=Msg)])

    def create(**kwargs):
        captured.update(kwargs)
        return resp

    c._client = types.SimpleNamespace(
        chat=types.SimpleNamespace(completions=types.SimpleNamespace(create=create))
    )
    return c


def test_complete_strips_think_block_and_sets_reasoning_flag():
    captured = {}
    c = _client_returning("<think>hmm</think> answer", captured)
    assert c.complete("sys", "user") == "answer"
    assert captured["messages"][0]["content"].startswith("detailed thinking off")


def test_reasoning_on_omits_flag():
    captured = {}
    c = _client_returning("ok", captured)
    c.reasoning_off = False
    c.complete("sys", "user")
    assert captured["messages"][0]["content"] == "sys"


def test_api_errors_wrapped():
    c = NebiusNemotronClient(api_key="k")

    def boom(**kwargs):
        raise RuntimeError("401")

    c._client = types.SimpleNamespace(
        chat=types.SimpleNamespace(completions=types.SimpleNamespace(create=boom))
    )
    with pytest.raises(LLMError):
        c.complete("s", "u")
