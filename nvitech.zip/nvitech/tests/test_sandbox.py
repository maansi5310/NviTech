from nvitech.sandbox import run_tests, scan_risky

GOOD = "def add(a, b):\n    return a + b\n"
BAD = "def add(a, b):\n    return a - b\n"
TESTS = "from solution import add\n\ndef test_add():\n    assert add(1, 2) == 3\n"


def test_passing_code():
    r = run_tests(GOOD, TESTS)
    assert r.passed and "1 passed" in r.summary


def test_failing_code_captures_output():
    r = run_tests(BAD, TESTS)
    assert not r.passed
    assert "assert" in r.output and "1 failed" in r.summary


def test_timeout():
    slow = "import time\n\ndef add(a, b):\n    time.sleep(30)\n    return a + b\n"
    r = run_tests(slow, TESTS, timeout=2)
    assert r.timed_out and not r.passed


def test_risky_code_blocked():
    evil = "import subprocess\n\ndef add(a, b):\n    subprocess.run(['ls'])\n    return a + b\n"
    r = run_tests(evil, TESTS)
    assert r.blocked and not r.passed


def test_scan_flags_calls_and_imports():
    findings = scan_risky("import os\nos.system('x')\nfrom socket import socket\neval('1')")
    assert len(findings) == 3


def test_scan_ignores_syntax_errors():
    assert scan_risky("def (") == []


def test_invalid_module_name():
    r = run_tests(GOOD, TESTS, module_name="../evil")
    assert not r.passed


def test_env_does_not_leak_keys(monkeypatch):
    monkeypatch.setenv("NEBIUS_API_KEY", "secret-123")
    code = "import os\n\ndef leaked():\n    return os.environ.get('NEBIUS_API_KEY')\n"
    tests = "from solution import leaked\n\ndef test_no_leak():\n    assert leaked() is None\n"
    assert run_tests(code, tests).passed
