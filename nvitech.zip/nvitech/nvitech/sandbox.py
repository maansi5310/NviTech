"""Restricted pytest runner.

IMPORTANT: this reduces risk but is NOT a hard security boundary. It combines
(1) a static scan that refuses obviously dangerous code, (2) a throwaway working
directory, (3) a stripped environment, (4) a wall-clock timeout, and (5) POSIX
resource limits (CPU, memory, file size). For untrusted input in production, run
the whole app inside a container or VM with no network.
"""

from __future__ import annotations

import ast
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import List

from .models import TestResult

RISKY_IMPORTS = {
    "subprocess", "socket", "shutil", "ctypes", "requests", "urllib",
    "http", "ftplib", "smtplib", "telnetlib", "multiprocessing", "pty",
}
RISKY_CALLS = {
    "os.system", "os.remove", "os.rmdir", "os.unlink", "os.removedirs",
    "os.popen", "os.execv", "os.execl", "os.kill", "os.fork",
    "eval", "exec", "compile", "__import__",
}


def _dotted(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _dotted(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    return ""


def scan_risky(source: str) -> List[str]:
    """Return human-readable findings for dangerous imports/calls."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []  # let pytest report the syntax error itself
    findings: List[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in RISKY_IMPORTS:
                    findings.append(f"line {node.lineno}: import of '{alias.name}'")
        elif isinstance(node, ast.ImportFrom) and node.module:
            if node.module.split(".")[0] in RISKY_IMPORTS:
                findings.append(f"line {node.lineno}: import from '{node.module}'")
        elif isinstance(node, ast.Call):
            name = _dotted(node.func)
            if name in RISKY_CALLS:
                findings.append(f"line {node.lineno}: call to '{name}'")
    return findings


def _limits(memory_mb: int, cpu_seconds: int):
    """Build a preexec_fn applying POSIX resource limits (None on Windows)."""
    if os.name != "posix":
        return None

    def apply() -> None:
        import resource

        mem = memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
        fsize = 10 * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))

    return apply


def _clean_env() -> dict:
    env = {
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONHASHSEED": "0",
        "PATH": os.environ.get("PATH", ""),
        "LANG": "C.UTF-8",
    }
    if os.name == "nt":
        env["SYSTEMROOT"] = os.environ.get("SYSTEMROOT", "")
    return env  # note: API keys are deliberately NOT passed through


def run_tests(
    code: str,
    test_code: str,
    module_name: str = "solution",
    timeout: int = 20,
    memory_mb: int = 1024,
    allow_risky: bool = False,
) -> TestResult:
    """Write code + tests into a temp dir and run pytest against them."""
    if not module_name.isidentifier():
        return TestResult(False, -1, stderr=f"Invalid module name: {module_name!r}",
                          summary="invalid module name")

    if not allow_risky:
        findings = scan_risky(code) + scan_risky(test_code)
        if findings:
            msg = "Blocked by safety scan:\n" + "\n".join(f"  - {f}" for f in findings)
            return TestResult(False, -1, stderr=msg, blocked=True,
                              summary="blocked by safety scan")

    start = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="nvitech_") as tmp:
        root = Path(tmp)
        (root / f"{module_name}.py").write_text(code, encoding="utf-8")
        (root / f"test_{module_name}_suite.py").write_text(test_code, encoding="utf-8")
        cmd = [
            sys.executable, "-m", "pytest", "-q", "--tb=short", "--no-header",
            "-p", "no:cacheprovider", "-p", "no:randomly", str(root),
        ]
        try:
            proc = subprocess.run(
                cmd,
                cwd=root,
                env=_clean_env(),
                capture_output=True,
                text=True,
                timeout=timeout,
                preexec_fn=_limits(memory_mb, timeout + 5),
            )
        except subprocess.TimeoutExpired as exc:
            return TestResult(
                False, -1,
                stdout=(exc.stdout or "") if isinstance(exc.stdout, str) else "",
                stderr=f"Timed out after {timeout}s",
                timed_out=True,
                duration=time.monotonic() - start,
                summary=f"timed out after {timeout}s",
            )

    lines = [ln for ln in proc.stdout.strip().splitlines() if ln.strip()]
    summary = lines[-1] if lines else "no output"
    return TestResult(
        passed=proc.returncode == 0,
        returncode=proc.returncode,
        stdout=proc.stdout,
        stderr=proc.stderr,
        duration=time.monotonic() - start,
        summary=summary,
    )
