"""Data models shared across the NviTech workflow."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class TestResult:
    """Outcome of running pytest in the sandbox."""

    passed: bool
    returncode: int
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    blocked: bool = False
    duration: float = 0.0
    summary: str = ""

    @property
    def output(self) -> str:
        parts = [p for p in (self.stdout.strip(), self.stderr.strip()) if p]
        return "\n".join(parts)


@dataclass
class Attempt:
    """One generate-and-test cycle."""

    number: int
    explanation: str
    fixed_code: str
    diff: str
    test_result: Optional[TestResult] = None
    parse_error: str = ""


@dataclass
class RepairReport:
    """Final report presented to the developer.

    status values:
      verified        - a patch was produced and the supplied tests pass
      unverified      - a patch was produced but no tests were supplied, so
                        nothing proves it works
      failed          - every attempt either failed the tests or was unusable
      already_passing - the supplied tests pass on the original code
      blocked         - the original code/tests were refused by the safety scan
    """

    status: str
    original_code: str
    analysis: str = ""
    plan: str = ""
    baseline: Optional[TestResult] = None
    attempts: List[Attempt] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def final_attempt(self) -> Optional[Attempt]:
        return self.attempts[-1] if self.attempts else None

    @property
    def best_code(self) -> Optional[str]:
        """The patched code to offer, only if it is verified or unverified."""
        if self.status in ("verified", "unverified") and self.final_attempt:
            return self.final_attempt.fixed_code
        return None
