"""NviTech: an AI debugging and code-repair agent."""

__version__ = "0.1.0"
