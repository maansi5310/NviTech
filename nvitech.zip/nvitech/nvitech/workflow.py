"""The NviTech repair workflow: analyze -> plan -> generate -> test -> iterate -> report."""

from __future__ import annotations

import difflib
import re
from typing import Callable, List, Optional, Tuple

from . import prompts
from .llm import LLM
from .models import Attempt, RepairReport, TestResult
from .sandbox import run_tests

EventCallback = Callable[[str, str], None]

_EXPL_RE = re.compile(r"<explanation>(.*?)</explanation>", re.DOTALL | re.IGNORECASE)
_CODE_RE = re.compile(r"<fixed_code>(.*?)</fixed_code>", re.DOTALL | re.IGNORECASE)
_FENCE_RE = re.compile(r"^```(?:python|py)?\s*\n(.*?)\n```\s*$", re.DOTALL)


def parse_generation(text: str) -> Tuple[str, str]:
    """Extract (explanation, code) from a model reply. Raises ValueError if unusable."""
    code_match = _CODE_RE.search(text)
    if not code_match:
        # Fallback: first fenced python block.
        fenced = re.search(r"```(?:python|py)?\s*\n(.*?)\n```", text, re.DOTALL)
        if not fenced:
            raise ValueError("Model reply contained no <fixed_code> block.")
        code, explanation = fenced.group(1), text.replace(fenced.group(0), "").strip()
    else:
        code = code_match.group(1).strip("\n")
        expl_match = _EXPL_RE.search(text)
        explanation = expl_match.group(1).strip() if expl_match else ""
    # Models sometimes wrap code in fences inside the tags.
    fence = _FENCE_RE.match(code.strip())
    if fence:
        code = fence.group(1)
    if not code.strip():
        raise ValueError("Model returned empty code.")
    return explanation or "(no explanation provided)", code.rstrip() + "\n"


def make_diff(old: str, new: str, name: str = "solution.py") -> str:
    return "".join(
        difflib.unified_diff(
            old.splitlines(keepends=True),
            new.splitlines(keepends=True),
            fromfile=f"a/{name}",
            tofile=f"b/{name}",
        )
    )


class RepairWorkflow:
    def __init__(
        self,
        llm: LLM,
        max_attempts: int = 3,
        timeout: int = 20,
        allow_risky: bool = False,
        on_event: Optional[EventCallback] = None,
    ) -> None:
        self.llm = llm
        self.max_attempts = max(1, max_attempts)
        self.timeout = timeout
        self.allow_risky = allow_risky
        self._emit = on_event or (lambda stage, msg: None)

    def _test(self, code: str, test_code: str, module_name: str) -> TestResult:
        return run_tests(
            code, test_code, module_name=module_name,
            timeout=self.timeout, allow_risky=self.allow_risky,
        )

    def run(
        self,
        code: str,
        test_code: str = "",
        traceback: str = "",
        module_name: str = "solution",
    ) -> RepairReport:
        report = RepairReport(status="failed", original_code=code)
        has_tests = bool(test_code.strip())

        # Baseline: run the tests on the original code to gather evidence.
        evidence = traceback.strip()
        if has_tests:
            self._emit("test", "Running tests on the original code…")
            report.baseline = self._test(code, test_code, module_name)
            if report.baseline.blocked:
                report.status = "blocked"
                report.notes.append(report.baseline.stderr)
                return report
            if report.baseline.passed and not evidence:
                report.status = "already_passing"
                report.notes.append(
                    "The supplied tests already pass on the original code, so there is "
                    "nothing to repair. Add a failing test or paste a traceback."
                )
                return report
            if not evidence:
                evidence = report.baseline.output
        else:
            report.notes.append(
                "No tests were supplied: any patch can only be marked UNVERIFIED."
            )

        # 1. Analyze
        self._emit("analyze", "Analyzing the likely root cause…")
        report.analysis = self.llm.complete(
            prompts.ANALYZE_SYSTEM, prompts.analyze_prompt(code, evidence)
        )

        # 2. Plan
        self._emit("plan", "Planning a minimal repair…")
        report.plan = self.llm.complete(
            prompts.PLAN_SYSTEM, prompts.plan_prompt(code, report.analysis)
        )

        # 3-5. Generate -> Test -> Iterate (bounded)
        failures: List[Tuple[str, str]] = []
        for n in range(1, self.max_attempts + 1):
            self._emit("generate", f"Attempt {n}/{self.max_attempts}: generating a patch…")
            raw = self.llm.complete(
                prompts.GENERATE_SYSTEM,
                prompts.generate_prompt(code, report.analysis, report.plan, test_code, failures),
            )
            try:
                explanation, fixed = parse_generation(raw)
            except ValueError as exc:
                attempt = Attempt(n, "", "", "", parse_error=str(exc))
                report.attempts.append(attempt)
                failures.append(("(no usable code returned)", str(exc)))
                self._emit("iterate", f"Attempt {n} unusable: {exc}")
                continue

            attempt = Attempt(n, explanation, fixed, make_diff(code, fixed, f"{module_name}.py"))
            report.attempts.append(attempt)

            if not has_tests:
                report.status = "unverified"
                self._emit("report", "Patch generated; no tests to verify it.")
                return report

            self._emit("test", f"Attempt {n}: running tests…")
            attempt.test_result = self._test(fixed, test_code, module_name)
            if attempt.test_result.passed:
                report.status = "verified"
                self._emit("report", f"Attempt {n} passed: {attempt.test_result.summary}")
                return report

            self._emit("iterate", f"Attempt {n} failed: {attempt.test_result.summary}")
            failures.append((fixed, attempt.test_result.output or attempt.test_result.summary))

        report.status = "failed"
        report.notes.append(
            f"No patch passed the tests within {self.max_attempts} attempt(s). "
            "Review the failure output below; the last patch is shown for reference only."
        )
        return report
