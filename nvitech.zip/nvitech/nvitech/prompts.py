"""Prompt templates for each workflow stage."""

ANALYZE_SYSTEM = (
    "You are a senior Python debugging assistant. Identify the root cause of the "
    "failure from the code and evidence given. Be concise and specific: name the "
    "function and line of reasoning. Do not write a fix yet."
)

PLAN_SYSTEM = (
    "You are a senior Python engineer. Given a root-cause analysis, write a short "
    "numbered repair plan that changes as little code as possible and keeps the "
    "public interface (function names, signatures) unchanged."
)

GENERATE_SYSTEM = (
    "You are a careful Python engineer producing a minimal fix. Return the COMPLETE "
    "corrected module, not a snippet. Keep function names and signatures. Do not "
    "modify tests. Do not add network, subprocess, or file-deletion code.\n\n"
    "Reply in exactly this format and nothing else:\n"
    "<explanation>\nWhat you changed and why, in a few sentences.\n</explanation>\n"
    "<fixed_code>\nthe full corrected module\n</fixed_code>"
)


def analyze_prompt(code: str, evidence: str) -> str:
    return (
        f"## Code\n```python\n{code}\n```\n\n"
        f"## Failure evidence (traceback / test output)\n```\n{evidence or 'None provided'}\n```\n\n"
        "What is the most likely root cause?"
    )


def plan_prompt(code: str, analysis: str) -> str:
    return (
        f"## Code\n```python\n{code}\n```\n\n## Root-cause analysis\n{analysis}\n\n"
        "Write the repair plan."
    )


def generate_prompt(
    code: str,
    analysis: str,
    plan: str,
    test_code: str,
    previous_failures: list[tuple[str, str]],
) -> str:
    """previous_failures: list of (attempted_code, failure_output)."""
    parts = [
        f"## Original code\n```python\n{code}\n```",
        f"## Root-cause analysis\n{analysis}",
        f"## Repair plan\n{plan}",
    ]
    if test_code.strip():
        parts.append(f"## Tests the fix must pass\n```python\n{test_code}\n```")
    for i, (attempt_code, failure) in enumerate(previous_failures, start=1):
        parts.append(
            f"## Failed attempt {i}\n```python\n{attempt_code}\n```\n"
            f"Result:\n```\n{failure[-3000:]}\n```\n"
            "This attempt did not work. Do not repeat it; address the actual failure above."
        )
    parts.append("Produce the corrected module now.")
    return "\n\n".join(parts)
