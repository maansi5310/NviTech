"""LLM access: Nebius Token Factory (OpenAI-compatible) serving NVIDIA Nemotron."""

from __future__ import annotations

import os
from typing import Protocol

# Token Factory exposes an OpenAI-compatible endpoint. Both values can be
# overridden in .env; check your Nebius console for the exact model slug
# available to your account.
DEFAULT_BASE_URL = "https://api.tokenfactory.nebius.com/v1/"
DEFAULT_MODEL = "nvidia/llama-3_1-nemotron-ultra-253b-v1"


class LLM(Protocol):
    def complete(self, system: str, user: str) -> str: ...


class LLMError(RuntimeError):
    """Raised when the model call cannot be completed."""


class NebiusNemotronClient:
    """Thin wrapper around the OpenAI SDK pointed at Nebius Token Factory."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        reasoning_off: bool | None = None,
    ) -> None:
        self.api_key = api_key or os.getenv("NEBIUS_API_KEY", "")
        self.base_url = base_url or os.getenv("NEBIUS_BASE_URL", DEFAULT_BASE_URL)
        self.model = model or os.getenv("NEBIUS_MODEL", DEFAULT_MODEL)
        self.temperature = temperature
        self.max_tokens = max_tokens
        if reasoning_off is None:
            reasoning_off = os.getenv("NEMOTRON_REASONING", "off").lower() == "off"
        self.reasoning_off = reasoning_off

        if not self.api_key:
            raise LLMError(
                "NEBIUS_API_KEY is not set. Copy .env.example to .env and add your key."
            )
        try:
            from openai import OpenAI
        except ImportError as exc:  # pragma: no cover
            raise LLMError("The 'openai' package is required: pip install openai") from exc
        self._client = OpenAI(base_url=self.base_url, api_key=self.api_key)

    def complete(self, system: str, user: str) -> str:
        # Llama-Nemotron models switch reasoning with a system-prompt keyword.
        system_prompt = (
            f"detailed thinking off\n\n{system}" if self.reasoning_off else system
        )
        try:
            resp = self._client.chat.completions.create(
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user},
                ],
            )
        except Exception as exc:  # network, auth, rate limit, bad model slug
            raise LLMError(f"Model call failed: {exc}") from exc
        content = resp.choices[0].message.content or ""
        # Strip any reasoning block if the model emits one.
        if "</think>" in content:
            content = content.split("</think>", 1)[1]
        return content.strip()
