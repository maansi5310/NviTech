"""NviTech - Streamlit UI.  Run with:  streamlit run app.py"""

from __future__ import annotations

import os
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

from nvitech.llm import DEFAULT_BASE_URL, DEFAULT_MODEL, LLMError, NebiusNemotronClient
from nvitech.workflow import RepairWorkflow

load_dotenv()
EXAMPLES = Path(__file__).parent / "examples"

st.set_page_config(page_title="NviTech", page_icon="🛠️", layout="wide")
st.title("🛠️ NviTech: AI Debugging & Code-Repair Agent")
st.caption("Analyze → Plan → Generate → Test → Iterate → Report. "
           "Powered by NVIDIA Nemotron on Nebius Token Factory.")

STATUS_BADGES = {
    "verified": ("✅ VERIFIED", "The patch passes the supplied tests."),
    "unverified": ("⚠️ UNVERIFIED", "A patch was generated but no tests were supplied, so it is not proven to work."),
    "failed": ("❌ FAILED", "No attempt passed the tests. Nothing below should be treated as a working fix."),
    "already_passing": ("ℹ️ NOTHING TO FIX", "The supplied tests already pass."),
    "blocked": ("⛔ BLOCKED", "The safety scan refused to run this code."),
}

# ---- Sidebar: configuration -------------------------------------------------
with st.sidebar:
    st.header("Configuration")
    api_key = st.text_input("Nebius API key", value=os.getenv("NEBIUS_API_KEY", ""), type="password")
    model = st.text_input("Model", value=os.getenv("NEBIUS_MODEL", DEFAULT_MODEL))
    base_url = st.text_input("Base URL", value=os.getenv("NEBIUS_BASE_URL", DEFAULT_BASE_URL))
    st.divider()
    max_attempts = st.slider("Max repair attempts", 1, 5, 3)
    timeout = st.slider("Test timeout (seconds)", 5, 60, 20)
    allow_risky = st.checkbox(
        "Allow risky imports/calls", value=False,
        help="Disables the static safety scan (subprocess, socket, os.system, eval...). "
             "Only enable in an isolated environment.",
    )
    st.info("The sandbox limits risk but is not a hard security boundary. "
            "Run NviTech in a container for untrusted code.")

# ---- Inputs -----------------------------------------------------------------
if "code" not in st.session_state:
    st.session_state.update(code="", tests="", trace="")

if st.button("Load buggy example"):
    st.session_state.code = (EXAMPLES / "solution.py").read_text()
    st.session_state.tests = (EXAMPLES / "test_solution.py").read_text()
    st.session_state.trace = ""

module_name = st.text_input("Module name (tests import from this)", value="solution")
left, right = st.columns(2)
with left:
    code = st.text_area("Code to repair", key="code", height=320)
    trace = st.text_area("Traceback / error message (optional)", key="trace", height=120)
with right:
    tests = st.text_area("pytest tests (strongly recommended)", key="tests", height=470,
                         help="Without tests a patch can never be marked verified.")

run = st.button("🔧 Repair", type="primary", disabled=not code.strip())

# ---- Run --------------------------------------------------------------------
if run:
    try:
        llm = NebiusNemotronClient(api_key=api_key, base_url=base_url, model=model)
    except LLMError as exc:
        st.error(str(exc))
        st.stop()

    with st.status("Working…", expanded=True) as status:
        workflow = RepairWorkflow(
            llm, max_attempts=max_attempts, timeout=timeout, allow_risky=allow_risky,
            on_event=lambda stage, msg: st.write(f"**{stage.title()}** · {msg}"),
        )
        try:
            report = workflow.run(code, tests, trace, module_name)
        except LLMError as exc:
            status.update(label="Model error", state="error")
            st.error(str(exc))
            st.stop()
        status.update(label="Done", state="complete", expanded=False)

    badge, blurb = STATUS_BADGES[report.status]
    (st.success if report.status == "verified" else st.warning if report.status in
     ("unverified", "already_passing") else st.error)(f"**{badge}**: {blurb}")
    for note in report.notes:
        st.write(f"- {note}")

    tabs = st.tabs(["Patch", "Reasoning", "Test evidence", "Attempts"])

    with tabs[0]:
        last = report.final_attempt
        if last and last.diff:
            if report.status == "failed":
                st.caption("Last attempt shown for reference only; it did NOT pass.")
            st.code(last.diff, language="diff")
            st.markdown("**Explanation**")
            st.write(last.explanation)
            st.download_button("Download patched file", last.fixed_code,
                               file_name=f"{module_name}.py")
        else:
            st.write("No patch produced.")

    with tabs[1]:
        st.markdown("**Root-cause analysis**")
        st.write(report.analysis or "n/a")
        st.markdown("**Repair plan**")
        st.write(report.plan or "n/a")

    with tabs[2]:
        if report.baseline:
            st.markdown(f"**Before:** `{report.baseline.summary}`")
            st.code(report.baseline.output or "(no output)")
        if last and last.test_result:
            st.markdown(f"**After:** `{last.test_result.summary}`")
            st.code(last.test_result.output or "(no output)")
        if not report.baseline and not (last and last.test_result):
            st.write("No tests were run.")

    with tabs[3]:
        for a in report.attempts:
            result = (a.test_result.summary if a.test_result else a.parse_error or "not tested")
            with st.expander(f"Attempt {a.number}: {result}"):
                if a.diff:
                    st.code(a.diff, language="diff")
                if a.test_result:
                    st.code(a.test_result.output)
